# Crisis Resources: Australia

## Emergency

**Emergency Services:** 000
For life-threatening emergencies, immediate danger, or risk of harm.

---

## Mental Health & Suicide Crisis

### Lifeline
**Phone:** 13 11 14 (24/7)
**Text:** 0477 13 11 14 (6pm-midnight)
**Online chat:** lifeline.org.au
Crisis support and suicide prevention for anyone in emotional distress.

### Suicide Call Back Service
**Phone:** 1300 659 467 (24/7)
**Online:** suicidecallbackservice.org.au
Free professional telephone and online counselling for anyone affected by suicide.

### Beyond Blue
**Phone:** 1300 22 4636 (24/7)
**Online chat:** beyondblue.org.au
Support for anxiety, depression, and suicide prevention.

### 13YARN
**Phone:** 13 92 76 (24/7)
Aboriginal and Torres Strait Islander crisis support line. Culturally safe support from trained Aboriginal and Torres Strait Islander crisis supporters.

---

## Young People

### Kids Helpline
**Phone:** 1800 55 1800 (24/7)
**Online:** kidshelpline.com.au
Free counselling for young people aged 5-25.

### Headspace
**Phone:** 1800 650 890
**Online:** headspace.org.au
Mental health support for young people aged 12-25.

---

## Family & Domestic Violence

### 1800RESPECT
**Phone:** 1800 737 732 (24/7)
**Text:** 0458 737 732
**Online chat:** 1800respect.org.au
National counselling, information and support for anyone affected by family, domestic or sexual violence.

### MensLine Australia
**Phone:** 1300 78 99 78 (24/7)
**Online:** mensline.org.au
Support for men dealing with family and relationship difficulties, including family violence.

---

## Sexual Assault

### 1800RESPECT
**Phone:** 1800 737 732 (24/7)
Includes support for sexual assault.

### Full Stop Australia
**Phone:** 1800 385 578
Support for anyone who has experienced sexual, domestic or family violence.

---

## Addiction & Substance Use

### Alcohol Drug Information Service (ADIS)
Contact details vary by state:
- NSW: 1800 250 015
- VIC: 1800 888 236
- QLD: 1800 177 833
- WA: 1800 198 024
- SA: 1300 131 340

### Gambling Helpline
**Phone:** 1800 858 858 (24/7)

---

## Specific Populations

### QLife (LGBTIQ+)
**Phone:** 1800 184 527 (3pm-midnight daily)
**Online chat:** qlife.org.au
Peer support for LGBTIQ+ people.

### PANDA (Perinatal)
**Phone:** 1300 726 306
Support for perinatal anxiety and depression.

### Thirrili (Aboriginal & Torres Strait Islander)
**Phone:** 1800 805 801 (24/7)
Support in aftermath of suicide or critical incidents for Aboriginal and Torres Strait Islander peoples.

---

## How Claude Should Use This

When someone in Australia appears to be in crisis:
1. Acknowledge their distress with compassion
2. Provide the most relevant resource for their situation
3. Encourage them to reach out
4. Lifeline (13 11 14) is the general-purpose crisis line
5. For immediate danger, always mention 000

Do not overwhelm with all resources at once. Choose 1-2 most relevant to their situation.
