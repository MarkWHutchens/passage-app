# Crisis Resources: Ireland

## Emergency

**Emergency Services:** 999 or 112
For life-threatening emergencies, immediate danger, or risk of harm.

---

## Mental Health & Suicide Crisis

### Samaritans Ireland
**Phone:** 116 123 (24/7, free)
**Email:** jo@samaritans.org
Confidential, non-judgmental support for anyone in distress.

### Pieta
**Phone:** 1800 247 247 (24/7, free)
**Text:** HELP to 51444
Free counselling for people with suicidal thoughts, engaging in self-harm, or bereaved by suicide. Staffed by qualified therapists.

### Text About It (50808)
**Text:** HELLO to 50808 (24/7)
Free, anonymous text support for anyone going through a mental health or emotional crisis.

### Aware
**Phone:** 1800 804 848 (10am-10pm daily)
**Email:** supportmail@aware.ie
Support for depression and bipolar disorder.

---

## Young People

### Childline
**Phone:** 1800 66 66 66 (24/7, free)
**Text:** 50101
**Chat:** childline.ie
Free, confidential support for anyone under 18.

### Jigsaw
**Website:** jigsaw.ie
Free mental health support for young people aged 12-25. Online support and local services available.

### SpunOut
**Text:** SPUNOUT to 086 1800 280
Text support for young people.

---

## Family & Domestic Violence

### Women's Aid
**Phone:** 1800 341 900 (24/7, free)
Support for women experiencing domestic violence.

### Men's Aid
**Phone:** 01 554 3811 (Mon-Fri 9am-5pm)
Support for men experiencing domestic abuse.

### AMEN
**Phone:** 046 902 3718
Support for male victims of domestic abuse.

---

## Sexual Assault

### Dublin Rape Crisis Centre
**Phone:** 1800 778 888 (24/7, free)
Support for anyone affected by rape, sexual assault, or childhood sexual abuse.

### One in Four
**Phone:** 01 662 4070
Support for adults who experienced sexual abuse or sexual violence as children.

---

## Addiction & Substance Use

### HSE Drugs & Alcohol Helpline
**Phone:** 1800 459 459 (Mon-Fri 9:30am-5:30pm)
**Email:** helpline@hse.ie
Information and support for drug and alcohol issues.

### Gamblers Anonymous Ireland
**Phone:** 01 872 1133
**Website:** gamblersanonymous.ie

### Alcoholics Anonymous Ireland
**Phone:** 01 842 0700
**Website:** alcoholicsanonymous.ie

---

## Specific Populations

### LGBT Ireland
**Phone:** 1800 929 539
Support for LGBTQ+ people and their families.

### Transgender Equality Network Ireland (TENI)
**Website:** teni.ie
Support and information for trans people.

### Shine (Mental Illness Support)
**Phone:** 1800 621 631
Support for people affected by mental illness.

### HUGG (Bereaved by Suicide)
**Website:** hugg.ie
Peer support groups for those bereaved by suicide.

---

## Other Supports

### Yourmentalhealth.ie
**Phone:** 1800 111 888
HSE information line for mental health services.

### GP Out of Hours
Contact your local GP out of hours service for urgent but non-emergency medical and mental health needs.

---

## How Claude Should Use This

When someone in Ireland appears to be in crisis:
1. Acknowledge their distress with compassion
2. Provide the most relevant resource for their situation
3. Encourage them to reach out
4. **Samaritans (116 123)** for emotional support
5. **Pieta (1800 247 247)** specifically for suicidal thoughts or self-harm
6. **Text 50808** for text-based support
7. For immediate danger, always mention 999 or 112

Do not overwhelm with all resources at once. Choose 1-2 most relevant to their situation.
