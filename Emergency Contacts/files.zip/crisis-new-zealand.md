# Crisis Resources: New Zealand / Aotearoa

## Emergency

**Emergency Services:** 111
For life-threatening emergencies, immediate danger, or risk of harm.

---

## Mental Health & Suicide Crisis

### 1737 Need to Talk
**Phone:** 1737 (24/7, free)
**Text:** 1737 (24/7, free)
National mental health and addictions helpline. Talk with a trained counsellor anytime.

### Lifeline Aotearoa
**Phone:** 0800 543 354 (0800 LIFELINE) (24/7)
**Text:** 4357 (HELP)
Crisis support and counselling.

### Suicide Crisis Helpline
**Phone:** 0508 828 865 (0508 TAUTOKO) (24/7)
For anyone thinking about suicide, or concerned about someone else.

### Samaritans
**Phone:** 0800 726 666 (24/7)
Confidential support for anyone who is lonely or in emotional distress.

---

## Young People

### Youthline
**Phone:** 0800 376 633 (24/7)
**Text:** 234
**Chat:** youthline.co.nz
**Instagram:** @youthlinenz
**WhatsApp:** 09 886 5696
Support for young people and their whānau.

### What's Up
**Phone:** 0800 942 8787 (11am-11pm daily)
**Chat:** Available 11am-10:30pm
For young people aged 5-19.

### Kidsline
**Phone:** 0800 543 754 (24/7)
For young people up to 18 years.

---

## Family & Domestic Violence

### Women's Refuge Crisis Line
**Phone:** 0800 733 843 (0800 REFUGE) (24/7)
For women living with violence or in fear.

### Shine
**Phone:** 0508 744 633 (24/7)
Family violence support and information.

### Are You OK
**Phone:** 0800 456 450 (24/7)
Family violence information and help.

### Shakti
**Phone:** 0800 742 584 (0800 SHAKTI) (24/7)
Multilingual helpline for migrant and refugee women experiencing family violence.

---

## Sexual Assault

### Safe to Talk
**Phone:** 0800 044 334 (24/7)
**Text:** 4334
Sexual harm helpline.

### National Rape & Sexual Abuse Crisis Line
**Phone:** 0800 883 300 (24/7)
Support after rape or sexual assault.

---

## Addiction & Substance Use

### Alcohol Drug Helpline
**Phone:** 0800 787 797 (24/7)
**Text:** 8681
**Chat:** alcoholdrughelp.org.nz
Support for alcohol and drug problems.

### Gambling Helpline
**Phone:** 0800 654 655 (24/7)
**Text:** 8006
**Chat:** gamblinghelpline.co.nz

---

## Mental Health Specific

### Depression Helpline
**Phone:** 0800 111 757 (24/7)
**Text:** 4202
Support for depression.

### Anxiety Helpline
**Phone:** 0800 269 4389 (0800 ANXIETY) (24/7)
Support for anxiety and panic.

---

## Specific Populations

### OUTLine (LGBTIQ+)
**Phone:** 0800 688 5463 (0800 OUTLINE) (6pm-9pm daily)
Support for sexuality and gender identity issues.

### Asian Family Services
**Phone:** 0800 862 342
Support in multiple languages for Asian communities.

### Yellow Brick Road
**Phone:** 0800 732 825
Support for families of people with mental illness.

### Skylight
**Phone:** 0800 299 100
Support through trauma, loss, and grief.

---

## How Claude Should Use This

When someone in New Zealand appears to be in crisis:
1. Acknowledge their distress with compassion
2. Provide the most relevant resource for their situation
3. Encourage them to reach out
4. **1737** (call or text) is the primary mental health line
5. **0508 TAUTOKO** for suicide-specific support
6. For immediate danger, always mention 111

Do not overwhelm with all resources at once. Choose 1-2 most relevant to their situation.
