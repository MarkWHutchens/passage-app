# Crisis Resources: United States

## Emergency

**Emergency Services:** 911
For life-threatening emergencies, immediate danger, or risk of harm.

---

## Mental Health & Suicide Crisis

### 988 Suicide & Crisis Lifeline
**Phone:** 988 (24/7)
**Text:** 988 (24/7)
**Chat:** 988lifeline.org
**Spanish:** Dial 988, then press 2
Free, confidential support for anyone in suicidal crisis or emotional distress. Also supports mental health and substance use crises.

### Crisis Text Line
**Text:** HOME to 741741 (24/7)
Free, confidential crisis support via text.

### Veterans Crisis Line
**Phone:** 988 (press 1)
**Text:** 838255
**Chat:** veteranscrisisline.net
Support for veterans, service members, and their families.

---

## Addiction & Substance Use

### SAMHSA National Helpline
**Phone:** 1-800-662-4357 (24/7)
Free, confidential treatment referral and information for mental health and substance use disorders. Available in English and Spanish.

### Alcoholics Anonymous
**Website:** aa.org (find local meetings)

### Narcotics Anonymous
**Phone:** 1-818-773-9999
**Website:** na.org

---

## Family & Domestic Violence

### National Domestic Violence Hotline
**Phone:** 1-800-799-7233 (24/7)
**Text:** START to 88788
**Chat:** thehotline.org
Support for anyone affected by domestic violence.

### National Dating Abuse Helpline
**Phone:** 1-866-331-9474
**Text:** LOVEIS to 22522
Support for young people in abusive relationships.

---

## Sexual Assault

### RAINN (Rape, Abuse & Incest National Network)
**Phone:** 1-800-656-4673 (24/7)
**Chat:** rainn.org
Support for survivors of sexual violence.

---

## Young People

### National Child Abuse Hotline
**Phone:** 1-800-422-4453 (24/7)
Support for children, parents, and concerned individuals.

### Teen Line
**Phone:** 1-800-852-8336 (6pm-10pm PT)
**Text:** TEEN to 839863
Peer support for teens.

### The Trevor Project (LGBTQ+ Youth)
**Phone:** 1-866-488-7386 (24/7)
**Text:** START to 678-678
**Chat:** thetrevorproject.org
Crisis support for LGBTQ+ young people.

---

## Specific Populations

### Trans Lifeline
**Phone:** 1-877-565-8860 (24/7)
Peer support for transgender people.

### National Alliance on Mental Illness (NAMI)
**Phone:** 1-800-950-6264 (Mon-Fri 10am-10pm ET)
**Text:** NAMI to 741741
Information and support for anyone affected by mental illness.

### Disaster Distress Helpline
**Phone:** 1-800-985-5990 (24/7)
**Text:** TalkWithUs to 66746
Support for people experiencing emotional distress related to disasters.

### Postpartum Support International
**Phone:** 1-800-944-4773
**Text:** 1-503-894-9453
Support for perinatal mental health.

---

## How Claude Should Use This

When someone in the United States appears to be in crisis:
1. Acknowledge their distress with compassion
2. Provide the most relevant resource for their situation
3. Encourage them to reach out
4. **988** is the primary crisis number (call or text)
5. For immediate danger, always mention 911

Do not overwhelm with all resources at once. Choose 1-2 most relevant to their situation.
