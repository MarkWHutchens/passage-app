# Crisis Resources: United Kingdom

## Emergency

**Emergency Services:** 999
For life-threatening emergencies, immediate danger, or risk of harm.

**NHS Mental Health Crisis:** 111 (option 2)
24/7 urgent mental health support.

---

## Mental Health & Suicide Crisis

### Samaritans
**Phone:** 116 123 (24/7, free)
**Email:** jo@samaritans.org
**Welsh Language Line:** 0808 164 0123 (7pm-11pm)
Confidential emotional support for anyone in distress or struggling to cope.

### SHOUT
**Text:** 85258 (24/7)
Free, confidential crisis text support. Text "SHOUT" to start.

### Campaign Against Living Miserably (CALM)
**Phone:** 0800 58 58 58 (5pm-midnight daily)
**Webchat:** thecalmzone.net
Support for anyone affected by suicide or suicidal thoughts.

### National Suicide Prevention Helpline UK
**Phone:** 0800 587 0800 (6pm-midnight daily)
Supportive listening service for anyone with thoughts of suicide.

### SANEline
**Phone:** 0300 304 7000 (4:30pm-10pm daily)
Emotional support and information for anyone affected by mental illness.

---

## Young People

### Childline
**Phone:** 0800 1111 (24/7)
**Online:** childline.org.uk
Free, confidential support for anyone under 19.

### Papyrus HOPELINE247
**Phone:** 0800 068 41 41 (24/7)
**Text:** 07860 039967
**Email:** pat@papyrus-uk.org
For under-35s struggling with suicidal feelings, or anyone concerned about a young person.

---

## Family & Domestic Violence

### National Domestic Abuse Helpline (Refuge)
**Phone:** 0808 2000 247 (24/7, free)
**Online chat:** nationaldahelpline.org.uk (Mon-Fri 10am-10pm)
Support for women experiencing domestic abuse.

### Men's Advice Line
**Phone:** 0808 801 0327 (Mon-Fri 10am-8pm)
For male victims of domestic abuse.

### Galop (LGBTQ+)
**Phone:** 0800 999 5428
**Email:** help@galop.org.uk
Support for LGBTQ+ people experiencing domestic abuse.

### Respect Phoneline
**Phone:** 0808 802 4040
For anyone concerned about their own violent behaviour.

---

## Sexual Assault

### Rape Crisis
**Phone:** 0808 500 2222 (24/7)
**Online chat:** rapecrisis.org.uk
Support for anyone affected by rape or sexual abuse.

### Survivors UK
**Phone:** 0203 598 3898 (Mon, Wed, Fri 10am-5pm; Tue, Thu 8am-8pm)
Support for male survivors of sexual abuse and rape.

---

## Addiction & Substance Use

### FRANK
**Phone:** 0300 123 6600 (24/7)
**Text:** 82111
Information and support about drugs.

### Drinkline
**Phone:** 0300 123 1110 (weekdays 9am-8pm, weekends 11am-4pm)
Confidential advice about alcohol.

### Gamblers Anonymous
**Phone:** 0330 094 0322
Support for gambling addiction.

---

## Specific Populations

### Switchboard LGBT+
**Phone:** 0800 0119 100 (10am-10pm daily)
**Email:** hello@switchboard.lgbt
Support for LGBTQ+ people on any issue.

### The Silver Line (Older People)
**Phone:** 0800 4 70 80 90 (24/7)
Support for people aged 55+.

### Combat Stress (Veterans)
**Phone:** 0800 138 1619 (24/7)
Mental health support for veterans.

---

## How Claude Should Use This

When someone in the UK appears to be in crisis:
1. Acknowledge their distress with compassion
2. Provide the most relevant resource for their situation
3. Encourage them to reach out
4. Samaritans (116 123) is the general-purpose crisis line
5. For immediate danger, always mention 999 or NHS 111 option 2

Do not overwhelm with all resources at once. Choose 1-2 most relevant to their situation.
