# Crisis Resources: Canada

## Emergency

**Emergency Services:** 911
For life-threatening emergencies, immediate danger, or risk of harm.

---

## Mental Health & Suicide Crisis

### 988 Suicide Crisis Helpline
**Phone:** 988 (24/7)
**Text:** 988 (24/7)
**Website:** 988.ca
Free, bilingual (English and French) crisis support for anyone thinking about suicide or worried about someone else. Launched November 2023.

### Kids Help Phone
**Phone:** 1-800-668-6868 (24/7)
**Text:** CONNECT to 686868
**Chat:** kidshelpphone.ca
Support for children and young adults.

### Hope for Wellness (Indigenous Peoples)
**Phone:** 1-855-242-3310 (24/7)
**Chat:** hopeforwellness.ca
Culturally competent support for Indigenous peoples. Services available in Cree, Ojibway, and Inuktitut upon request.

### Crisis Services Canada
**Phone:** 1-833-456-4566 (24/7)
**Text:** 45645 (4pm-midnight ET)

---

## Provincial Crisis Lines

Crisis lines vary by province. Here are some key provincial resources:

### Ontario
- Connex Ontario: 1-866-531-2600

### Quebec
- Tel-Aide: 514-935-1101
- Suicide Action Montreal: 1-866-APPELLE (277-3553)

### British Columbia
- Crisis Centre BC: 1-800-784-2433

### Alberta
- Mental Health Helpline: 1-877-303-2642
- Distress Centre Calgary: 403-266-4357

### Other Provinces
- Check 988.ca for routing to local crisis centres

---

## Family & Domestic Violence

### Assaulted Women's Helpline (Ontario)
**Phone:** 1-866-863-0511 (24/7)

### SOS Violence Conjugale (Quebec)
**Phone:** 1-800-363-9010 (24/7)

### VictimLinkBC (British Columbia)
**Phone:** 1-800-563-0808 (24/7)

Provincial resources vary. For national information:
**Government of Canada:** canada.ca/family-violence

---

## Sexual Assault

Provincial sexual assault centres vary. Search for local resources or contact:
- Kids Help Phone: 1-800-668-6868 (for young people)
- 988 can provide referrals to local resources

---

## Addiction & Substance Use

### Connex Ontario (Ontario)
**Phone:** 1-866-531-2600
Mental health and addictions information.

### Alcohol and Drug Information Referral
Provincial services vary:
- BC: 1-800-663-1441
- Alberta: 1-866-332-2322
- Ontario: 1-800-565-8603

### Gamblers Anonymous
**Website:** gacanada.ca

---

## Specific Populations

### Trans Lifeline
**Phone:** 1-877-330-6366 (24/7)
Peer support for trans people.

### Interligne (LGBTQ+ - Quebec)
**Phone:** 1-888-505-1010
**Chat:** interligne.co

### First Nations and Inuit Hope for Wellness
**Phone:** 1-855-242-3310 (24/7)
Culturally appropriate crisis support.

---

## How Claude Should Use This

When someone in Canada appears to be in crisis:
1. Acknowledge their distress with compassion
2. Provide the most relevant resource for their situation
3. Encourage them to reach out
4. **988** is now the primary crisis number in Canada (call or text)
5. For immediate danger, always mention 911

Do not overwhelm with all resources at once. Choose 1-2 most relevant to their situation.
